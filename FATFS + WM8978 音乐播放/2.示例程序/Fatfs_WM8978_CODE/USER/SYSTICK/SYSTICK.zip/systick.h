#ifndef __SYSTICK_H
#define __SYSTICK_H

#include "stm32f4xx.h" 

void Systick_Inti(unsigned char clk);
void Delay_Us(unsigned int us);

#endif
