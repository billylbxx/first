#ifndef _INTEGER

typedef unsigned char	BYTE;
typedef unsigned short	WORD;
typedef unsigned long	DWORD;

typedef unsigned char	BOOL;
#define FALSE	0
#define TRUE	1

#define _INTEGER
#endif
